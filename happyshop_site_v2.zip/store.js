// Default sample images (SVG data URLs)
const defaultImage = 'data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600"><rect width="100%" height="100%" fill="#ffe6ea"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="36" fill="#ff6b81">HappyShop</text></svg>');

let products = JSON.parse(localStorage.getItem('products')) || [
  { id:'p1', name:'Cute Mug', price:12.99, category:'Home', description:'Ceramic mug — 300ml', image:defaultImage },
  { id:'p2', name:'Comfy Socks', price:6.50, category:'Clothing', description:'Soft cotton socks', image:defaultImage },
  { id:'p3', name:'Notebook', price:8.00, category:'Stationery', description:'A5 notebook, 80 pages', image:defaultImage },
  { id:'p4', name:'Kids Toy', price:14.99, category:'Toys', description:'Safe and fun', image:defaultImage }
];

function saveProducts(){ localStorage.setItem('products', JSON.stringify(products)); }

// CART utilities
function loadCart(){ return JSON.parse(localStorage.getItem('cart')) || []; }
function saveCart(c){ localStorage.setItem('cart', JSON.stringify(c)); updateCartCount(); }
function updateCartCount(){ const c = loadCart().reduce((s,i)=>s+i.qty,0); const el=document.getElementById('cart-count'); if(el) el.textContent=c; }

function addToCart(index){ const prod = products[index]; if(!prod) return; addToCartById(prod.id); }
function addToCartById(id){ const cart = loadCart(); const item = cart.find(i=>i.id===id); if(item){ item.qty +=1; } else { cart.push({ id, qty:1 }); } saveCart(cart); updateCartCount(); alert('Added to cart'); }
function changeQty(id,delta){ const cart = loadCart(); const item = cart.find(i=>i.id===id); if(!item) return; item.qty += delta; if(item.qty<1) item.qty=1; saveCart(cart); location.reload(); }
function removeFromCart(id){ let cart = loadCart(); cart = cart.filter(i=>i.id!==id); saveCart(cart); location.reload(); }

// Utilities used across pages
function addSampleProductsIfEmpty(){ if(products.length===0){ saveProducts(); } }
addSampleProductsIfEmpty(); saveProducts(); updateCartCount();
